<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Users</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>c4704153-f422-40c8-a55d-118417928d0c</testSuiteGuid>
   <testCaseLink>
      <guid>692f5836-a365-4a88-91c7-ad2f9af42f72</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/User/ListUser</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b9acda16-c8e2-49f2-9035-a82373aaa00c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/User/RegisterSuccesfull</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>68d817b6-cc7a-46e8-a41e-00f5f836b159</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/User/GetSingleUser</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e0ffcfac-22d2-4f48-ba2e-3c9abca84858</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/User/Update</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
